from django.shortcuts import render,redirect
from app.models import Shop
from app.forms import ConformationForm
from django.contrib.auth.decorators import login_required
import razorpay

# Create your views here.

def get_products(request):
    shop=Shop.objects.all()
    item_name=request.GET.get('item_name')

    if item_name!=''and item_name is not None:
        shop=shop.filter(name__contains=item_name,price__gt=3000)

    my_dict={'shop':shop}

    return render(request,"home1.html",my_dict)


def Shop_Data(request,id):
    shop=Shop.objects.get(id=id)
    return render(request,"read.html",{'shop':shop})
@login_required
def Conformation_Data(request):
    form=ConformationForm()
    ecommerce=Shop.objects.all()
    if request.method=='POST':
        form=ConformationForm(request.POST)
        order_amount = 5000000
        order_currency = 'INR'
        client=razorpay.Client(auth=('rzp_test_zu6unzntUX44Xo','yGlmWWF539D63gCxIRUSI6GQ'))
        payment=client.order.create(amount=order_amount, currency=order_currency,  notes=notes)

        if form.is_valid():
            form.save(commit=True)
        return redirect('/home')

    my_dict={'form':form,'ecommerce':ecommerce}
    return render(request,"order.html",my_dict)

def Signup(request):
    return render(request,"signup.html")


def logout(request):
    return render(request,"logout.html")

"""def confirm_view(request):
    if request.method=='POST':
        order_amount = 5000000
        order_currency = 'INR'
        client=razorpay.Client(auth=('rzp_test_3WcdY7UpiOvxim','A0UNw9coiX5uEKgAmDFEdEnF'))
        payment=client.order.create(amount=order_amount, currency=order_currency,  notes=notes)
    ecommerce=Shop.objects.all()
    my_dict={'ecommerce':ecommerce}
    return render(request,"checkout.html",my_dict)
"""
