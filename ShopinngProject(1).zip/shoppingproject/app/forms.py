from django import forms
from app.models import Conformation

class ConformationForm(forms.ModelForm):

    class Meta:
        model=Conformation
        fields="__all__"
