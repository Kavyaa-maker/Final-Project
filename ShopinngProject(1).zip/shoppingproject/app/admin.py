from django.contrib import admin
from app.models import Shop,Conformation
# Register your models here.

class ShopAdmin(admin.ModelAdmin):
    list_display=['name','price','discounted_price','category','Features','image']

class ConformationAdmin(admin.ModelAdmin):
    list_display=['first_name','last_name','phone_no','address','email','city','state','pincode','landmark']

admin.site.register(Shop,ShopAdmin)
admin.site.register(Conformation,ConformationAdmin)
