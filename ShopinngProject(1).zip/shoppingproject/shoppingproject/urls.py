from django.contrib import admin
from django.urls import path,include
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.get_products),
    path('accounts/', include("django.contrib.auth.urls")),
    path('read/<int:id>', views.Shop_Data),
    path('conform/', views.Conformation_Data),
    path('signup/', views.Signup),
    path('logout/', views.logout),
]
